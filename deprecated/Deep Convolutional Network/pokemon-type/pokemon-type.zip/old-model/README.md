# Predict-Pokemon-Type-CNN
Predict pokemon types Generation 4 and above using Deep Convolutional Neural Network, trained using third Generation only

Seems Convolutional Neural Network is serious matter for labelling, I am not expecting a good outcome from this model.

I only trained using Generation I, II, and III to predict Generation IV, seems okey enough.

![alt text](output/graph.png)

![alt text](output/output.png)

![alt text](output/output_gen3.png)

![alt text](output/output_diamond_pearl.png)
